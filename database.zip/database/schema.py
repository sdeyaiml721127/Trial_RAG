"""
supply_chain_loader.py
Hybrid version: Inserts data into normalized SQLite tables + 
adds tamper-proof blockchain logs + queryable audit table.
"""

from sqlalchemy import (
    create_engine, Column, Integer, Float, String, ForeignKey, DateTime, Text
)
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
import pandas as pd
import datetime
from audit_chain import AuditChain  # Import Blockchain Audit

# ==========================================================
# Step 1: Database Connection Setup
# ==========================================================
engine = create_engine("sqlite:///supply_chain_data.db", echo=False)
Base = declarative_base()

# ==========================================================
# Step 2: Define ORM Models
# ==========================================================

class Product(Base):
    __tablename__ = "products"
    product_id = Column(Integer, primary_key=True, autoincrement=True)
    product_type = Column(String)
    sku = Column(String, unique=True)
    price = Column(Float)
    availability = Column(Integer)
    stock_level = Column(Integer)

    sales = relationship("Sale", back_populates="product")
    manufacturing = relationship("Manufacturing", back_populates="product")
    shipping = relationship("Shipping", back_populates="product")


class Supplier(Base):
    __tablename__ = "suppliers"
    supplier_id = Column(Integer, primary_key=True, autoincrement=True)
    supplier_name = Column(String)
    location = Column(String)
    supplier_lead_time = Column(Integer)

    manufacturing = relationship("Manufacturing", back_populates="supplier")
    shipping = relationship("Shipping", back_populates="supplier")


class Sale(Base):
    __tablename__ = "sales"
    sale_id = Column(Integer, primary_key=True, autoincrement=True)
    product_id = Column(Integer, ForeignKey("products.product_id"))
    num_sold = Column(Integer)
    revenue_generated = Column(Float)
    customer_demographics = Column(String)

    product = relationship("Product", back_populates="sales")


class Manufacturing(Base):
    __tablename__ = "manufacturing"
    manufacturing_id = Column(Integer, primary_key=True, autoincrement=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.supplier_id"))
    product_id = Column(Integer, ForeignKey("products.product_id"))
    production_volume = Column(Integer)
    manufacturing_lead_time = Column(Integer)
    manufacturing_cost = Column(Float)
    inspection_result = Column(String)
    defect_rate = Column(Float)

    supplier = relationship("Supplier", back_populates="manufacturing")
    product = relationship("Product", back_populates="manufacturing")


class Shipping(Base):
    __tablename__ = "shipping"
    shipping_id = Column(Integer, primary_key=True, autoincrement=True)
    product_id = Column(Integer, ForeignKey("products.product_id"))
    supplier_id = Column(Integer, ForeignKey("suppliers.supplier_id"))
    carrier = Column(String)
    transportation_mode = Column(String)
    route = Column(String)
    shipping_time = Column(Integer)
    shipping_cost = Column(Float)
    order_quantity = Column(Integer)
    total_cost = Column(Float)

    product = relationship("Product", back_populates="shipping")
    supplier = relationship("Supplier", back_populates="shipping")


# ==========================================================
# Step 3: Add Hybrid Audit Table
# ==========================================================

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, default=datetime.datetime.now)
    action = Column(String)
    user_query = Column(Text)
    sql_query = Column(Text)
    hash_value = Column(String)


# ==========================================================
# Step 4: Create all tables
# ==========================================================
Base.metadata.create_all(engine)

# ==========================================================
# Step 5: Session + Blockchain Initialization
# ==========================================================
Session = sessionmaker(bind=engine)
session = Session()

audit_chain = AuditChain(file_path="audit_chain.json")  # Blockchain instance

# ==========================================================
# Step 6: Load CSV Data
# ==========================================================
df = pd.read_csv("supply_chain_data.csv")
df.columns = df.columns.str.strip()

# ==========================================================
# Step 7: Insert Data + Hybrid Audit
# ==========================================================
for _, row in df.iterrows():
    try:
        # --- Product ---
        product = session.query(Product).filter_by(sku=row["SKU"]).first()
        if not product:
            product = Product(
                product_type=row["Product type"],
                sku=row["SKU"],
                price=float(row["Price"]),
                availability=int(row["Availability"]),
                stock_level=int(row["Stock levels"])
            )
            session.add(product)
            session.flush()

        # --- Supplier ---
        supplier = session.query(Supplier).filter_by(
            supplier_name=row["Supplier name"],
            location=row["Location"]
        ).first()
        if not supplier:
            supplier = Supplier(
                supplier_name=row["Supplier name"],
                location=row["Location"],
                supplier_lead_time=int(row["Lead time"])
            )
            session.add(supplier)
            session.flush()

        # --- Sales ---
        sale = Sale(
            product_id=product.product_id,
            num_sold=int(row["Number of products sold"]),
            revenue_generated=float(row["Revenue generated"]),
            customer_demographics=row["Customer demographics"]
        )
        session.add(sale)

        # --- Manufacturing ---
        manuf = Manufacturing(
            supplier_id=supplier.supplier_id,
            product_id=product.product_id,
            production_volume=int(row["Production volumes"]),
            manufacturing_lead_time=int(row["Manufacturing lead time"]),
            manufacturing_cost=float(row["Manufacturing costs"]),
            inspection_result=row["Inspection results"],
            defect_rate=float(row["Defect rates"])
        )
        session.add(manuf)

        # --- Shipping ---
        ship = Shipping(
            product_id=product.product_id,
            supplier_id=supplier.supplier_id,
            carrier=row["Shipping carriers"],
            transportation_mode=row["Transportation modes"],
            route=row["Routes"],
            shipping_time=int(row["Shipping times"]),
            shipping_cost=float(row["Shipping costs"]),
            order_quantity=int(row["Order quantities"]),
            total_cost=float(row["Costs"])
        )
        session.add(ship)

        # Commit batch
        session.commit()

        # --- Hybrid Audit ---
        user_query = f"Inserted SKU {row['SKU']} from CSV"
        sql_query = f"INSERT operations across multiple tables for SKU {row['SKU']}"

        # 1️⃣ Add blockchain block
        audit_chain.add_block(user_query, sql_query)

        # 2️⃣ Store audit record in DB
        session.add(
            AuditLog(
                action="CSV Insert",
                user_query=user_query,
                sql_query=sql_query,
                hash_value=audit_chain.chain[-1].hash
            )
        )
        session.commit()

    except Exception as e:
        session.rollback()
        print(f"⚠️ Error processing row {row.get('SKU', 'Unknown')}: {e}")

session.close()

print("✅ CSV successfully converted and audited (Hybrid Blockchain + SQL Logs)")
