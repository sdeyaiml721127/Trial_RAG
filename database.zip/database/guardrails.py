"""
guardrails.py
Implements privacy, language, and SQL safety guardrails for the SQL Agent.
All guardrail actions are logged using GuardrailsLogger.
"""

import re
from typing import Any
from langchain_openai import ChatOpenAI

from guardrails_logger import GuardrailsLogger
from audit_chain import AuditChain


# Optional blockchain integration for tamper-proof logging
audit_chain = AuditChain("audit_chain.json")


# ---------------------------------------------------------------------
# 🧩 1. SQL Safety Guardrail
# ---------------------------------------------------------------------
def is_safe_sql(query: str) -> bool:
    """
    Blocks dangerous SQL statements that modify or delete data.
    """
    blocked_keywords = ["DROP", "DELETE", "ALTER", "TRUNCATE", "INSERT", "UPDATE"]
    is_safe = not any(keyword in query.upper() for keyword in blocked_keywords)

    if is_safe:
        GuardrailsLogger.log_event("SQL Safety", query, "✅ Safe query approved")
    else:
        GuardrailsLogger.log_event("SQL Safety", query, "🚫 Unsafe SQL operation blocked")
        audit_chain.add_block("SQL Safety", f"Blocked SQL: {query}")

    return is_safe


# ---------------------------------------------------------------------
# 🧩 2. PII Privacy Guardrail
# ---------------------------------------------------------------------
def scrub_pii(text: str) -> str:
    """
    Redacts sensitive personal information from text outputs.
    """
    patterns = {
        "email": r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}",
        "phone": r"\b\d{10}\b",
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "aadhaar": r"\b\d{4}\s\d{4}\s\d{4}\b",
    }

    redacted = text
    for key, pattern in patterns.items():
        if re.search(pattern, text):
            redacted = re.sub(pattern, f"[REDACTED_{key.upper()}]", redacted)
            GuardrailsLogger.log_event("PII Filter", text, f"🔒 {key.upper()} redacted")
            audit_chain.add_block("PII Filter", f"Redacted {key.upper()} in text")

    if redacted == text:
        GuardrailsLogger.log_event("PII Filter", text, "✅ No PII detected")

    return redacted


# ---------------------------------------------------------------------
# 🧩 3. Language / Tone Guardrail
# ---------------------------------------------------------------------
def moderate_language(user_input: str, llm: ChatOpenAI) -> None:
    """
    Uses LLM moderation to ensure user inputs are polite and appropriate.
    """
    moderation_prompt = f"""
    You are a moderation assistant. Analyze this message for safety:
    "{user_input}"
    Respond with:
    - "OK" if the message is safe and professional.
    - "BLOCK" if it contains hate, threats, harassment, or offensive content.
    """
    result = llm.invoke(moderation_prompt)

    if "BLOCK" in result.content.upper():
        GuardrailsLogger.log_event("Language Filter", user_input, "🚫 Inappropriate content blocked")
        audit_chain.add_block("Language Filter", f"Blocked input: {user_input}")
        raise ValueError("🚫 Inappropriate or unsafe language detected.")
    else:
        GuardrailsLogger.log_event("Language Filter", user_input, "✅ Safe input approved")


# ---------------------------------------------------------------------
# 🧩 4. Unified Guardrail Entry Point
# ---------------------------------------------------------------------
def apply_guardrails(user_input: str, sql_query: str | None, llm: ChatOpenAI, results: Any = None) -> Any:
    """
    Applies all guardrails before and after SQL execution.
    """
    # Step 1: Language moderation
    moderate_language(user_input, llm)

    # Step 2: SQL safety check
    if sql_query and not is_safe_sql(sql_query):
        raise ValueError("⚠️ Unsafe SQL operation detected. Query blocked.")

    # Step 3: Clean results (remove PII)
    if results:
        return scrub_pii(str(results))

    GuardrailsLogger.log_event("Guardrails", user_input, "✅ All guardrails passed")
    return None
