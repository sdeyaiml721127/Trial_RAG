"""
audit_chain.py
Implements blockchain-based tamper-proof audit logging for the SQL Agent.
Each transaction stores:
  - user query
  - generated SQL
  - timestamp
  - hash chain integrity
"""

import hashlib
import os
import json
import datetime


# -------------------------------------------------------
# 🧩 Simple Blockchain Block
# -------------------------------------------------------
class Block:
    def __init__(self, index, timestamp, user_query, sql_query, previous_hash):
        self.index = index
        self.timestamp = timestamp
        self.user_query = user_query
        self.sql_query = sql_query
        self.previous_hash = previous_hash
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        record = f"{self.index}{self.timestamp}{self.user_query}{self.sql_query}{self.previous_hash}"
        return hashlib.sha256(record.encode()).hexdigest()


# -------------------------------------------------------
# 🧩 Blockchain Manager
# -------------------------------------------------------
class AuditChain:
    def __init__(self, file_path="audit_chain.json"):
        self.file_path = file_path
        self.chain = self.load_chain()

    def create_genesis_block(self):
        return Block(0, str(datetime.datetime.now()), "Genesis Block", "N/A", "0")

    def load_chain(self):
        if os.path.exists(self.file_path):
            with open(self.file_path, "r") as f:
                data = json.load(f)
                return [
                    Block(
                        i["index"],
                        i["timestamp"],
                        i["user_query"],
                        i["sql_query"],
                        i["previous_hash"],
                    )
                    for i in data
                ]
        else:
            return [self.create_genesis_block()]

    def add_block(self, user_query, sql_query):
        last_block = self.chain[-1]
        new_block = Block(
            len(self.chain),
            str(datetime.datetime.now()),
            user_query,
            sql_query,
            last_block.hash,
        )
        self.chain.append(new_block)
        self.save_chain()

    def save_chain(self):
        with open(self.file_path, "w") as f:
            json.dump(
                [
                    {
                        "index": b.index,
                        "timestamp": b.timestamp,
                        "user_query": b.user_query,
                        "sql_query": b.sql_query,
                        "previous_hash": b.previous_hash,
                        "hash": b.hash,
                    }
                    for b in self.chain
                ],
                f,
                indent=4,
            )

    def verify_integrity(self):
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            previous = self.chain[i - 1]
            if current.previous_hash != previous.hash:
                return False
        return True