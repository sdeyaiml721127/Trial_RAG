from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import create_sql_agent
from langchain_openai import ChatOpenAI
import ssl
import urllib3
import requests
import httpx
import os
from dotenv import load_dotenv
ssl._create_default_https_context = ssl._create_unverified_context
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
requests.get = lambda *args, **kwargs: requests.api.get(*args, verify=False, **kwargs)

load_dotenv()

# 1. Load SQLite DB
db = SQLDatabase.from_uri("sqlite:///supply_chain_data.db")

# 2. Initialize LLM
client = httpx.Client(verify=False)
llm = ChatOpenAI( 
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-gpt-35-turbo",
    api_key=os.getenv("GENAILAB_API_KEY"),
    http_client=client
)

# 3. Create SQL Agent (new API)
agent = create_sql_agent(
    llm=llm,
    db=db,
    verbose=False,
)

# 4. Ask questions in loop
# questions = [
#     "How many users are in the database?",
#     "List all user names.",
#     "What is the email of Bob?",
# ]

# for q in questions:
#     # print(f"\n❓ Question: {q}")
#     response = agent.invoke({"input": q})
#     # print("👉 Answer:", response["output"])
#     answer = response.get("output")
#     print(answer)

# For single question
q = "How many unique product types are in the database?"
response = agent.invoke({"input": q})
answer = response.get("output")
print(answer)
