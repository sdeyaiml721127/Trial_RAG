import pandas as pd
import datetime
from sqlalchemy import (
    create_engine, Column, Integer, Float, String, ForeignKey, DateTime, Text
)
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
from audit_chain import AuditChain  # Required dependency from your uploads

# ==========================================================
# Step 1: Database Connection Setup
# ==========================================================
engine = create_engine("sqlite:///supply_chain_data.db", echo=False)
Base = declarative_base()

# ==========================================================
# Step 2: Define ORM Models
# ==========================================================

class Product(Base):
    __tablename__ = "products"
    product_id = Column(Integer, primary_key=True, autoincrement=True)
    product_type = Column(String)
    sku = Column(String, unique=True)
    price = Column(Float)
    availability = Column(Integer)
    stock_level = Column(Integer)

    sales = relationship("Sale", back_populates="product")
    manufacturing = relationship("Manufacturing", back_populates="product")
    shipping = relationship("Shipping", back_populates="product")


class Supplier(Base):
    __tablename__ = "suppliers"
    supplier_id = Column(Integer, primary_key=True, autoincrement=True)
    supplier_name = Column(String)
    location = Column(String)
    supplier_lead_time = Column(Integer)

    manufacturing = relationship("Manufacturing", back_populates="supplier")
    shipping = relationship("Shipping", back_populates="supplier")


class Sale(Base):
    __tablename__ = "sales"
    sale_id = Column(Integer, primary_key=True, autoincrement=True)
    product_id = Column(Integer, ForeignKey("products.product_id"))
    num_sold = Column(Integer)
    revenue_generated = Column(Float)
    customer_demographics = Column(String)

    product = relationship("Product", back_populates="sales")


class Manufacturing(Base):
    __tablename__ = "manufacturing"
    manufacturing_id = Column(Integer, primary_key=True, autoincrement=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.supplier_id"))
    product_id = Column(Integer, ForeignKey("products.product_id"))
    production_volume = Column(Integer)
    manufacturing_lead_time = Column(Integer)
    manufacturing_cost = Column(Float)
    inspection_result = Column(String)
    defect_rate = Column(Float)

    supplier = relationship("Supplier", back_populates="manufacturing")
    product = relationship("Product", back_populates="manufacturing")


class Shipping(Base):
    __tablename__ = "shipping"
    shipping_id = Column(Integer, primary_key=True, autoincrement=True)
    product_id = Column(Integer, ForeignKey("products.product_id"))
    supplier_id = Column(Integer, ForeignKey("suppliers.supplier_id"))
    carrier = Column(String)
    transportation_mode = Column(String)
    route = Column(String)
    shipping_time = Column(Integer)
    shipping_cost = Column(Float)
    order_quantity = Column(Integer)
    total_cost = Column(Float)

    product = relationship("Product", back_populates="shipping")
    supplier = relationship("Supplier", back_populates="shipping")


# ==========================================================
# Step 3: Add Hybrid Audit Table
# ==========================================================

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, default=datetime.datetime.now)
    action = Column(String)
    user_query = Column(Text)
    sql_query = Column(Text)
    hash_value = Column(String)


# ==========================================================
# Step 4: Create all tables
# ==========================================================
Base.metadata.create_all(engine)

# ==========================================================
# Step 5: Session + Blockchain Initialization
# ==========================================================
Session = sessionmaker(bind=engine)
session = Session()

# Initialize the blockchain ledger from your existing code
audit_chain = AuditChain(file_path="audit_chain.json")

# ==========================================================
# Step 6: Load CSV Data
# ==========================================================
try:
    df = pd.read_csv("../data/supply_chain_data.csv")
    df.columns = df.columns.str.strip()  # Remove accidental whitespace from headers
    print("📋 CSV loaded successfully. Starting conversion...")
except FileNotFoundError:
    print("❌ Error: 'supply_chain_data.csv' not found.")
    exit()

# ==========================================================
# Step 7: Insert Data + Hybrid Audit
# ==========================================================
for index, row in df.iterrows():
    try:
        # --- Product Normalization ---
        # Check if product exists to avoid duplicates
        product = session.query(Product).filter_by(sku=row["SKU"]).first()
        if not product:
            product = Product(
                product_type=row["Product type"],
                sku=row["SKU"],
                price=float(row["Price"]),
                availability=int(row["Availability"]),
                stock_level=int(row["Stock levels"])
            )
            session.add(product)
            session.flush() # Flush to get the product_id for foreign keys

        # --- Supplier Normalization ---
        # Check if supplier exists to avoid duplicates
        supplier = session.query(Supplier).filter_by(
            supplier_name=row["Supplier name"],
            location=row["Location"]
        ).first()
        if not supplier:
            supplier = Supplier(
                supplier_name=row["Supplier name"],
                location=row["Location"],
                supplier_lead_time=int(row["Lead time"])
            )
            session.add(supplier)
            session.flush() # Flush to get the supplier_id

        # --- Sales Data ---
        sale = Sale(
            product_id=product.product_id,
            num_sold=int(row["Number of products sold"]),
            revenue_generated=float(row["Revenue generated"]),
            customer_demographics=row["Customer demographics"]
        )
        session.add(sale)

        # --- Manufacturing Data ---
        manuf = Manufacturing(
            supplier_id=supplier.supplier_id,
            product_id=product.product_id,
            production_volume=int(row["Production volumes"]),
            manufacturing_lead_time=int(row["Manufacturing lead time"]),
            manufacturing_cost=float(row["Manufacturing costs"]),
            inspection_result=row["Inspection results"],
            defect_rate=float(row["Defect rates"])
        )
        session.add(manuf)

        # --- Shipping Data ---
        ship = Shipping(
            product_id=product.product_id,
            supplier_id=supplier.supplier_id,
            carrier=row["Shipping carriers"],
            transportation_mode=row["Transportation modes"],
            route=row["Routes"],
            shipping_time=int(row["Shipping times"]),
            shipping_cost=float(row["Shipping costs"]),
            order_quantity=int(row["Order quantities"]),
            total_cost=float(row["Costs"])
        )
        session.add(ship)

        # Commit the transaction for this row
        session.commit()

        # --- Hybrid Audit Logging ---
        user_query_log = f"Inserted SKU {row['SKU']} from CSV"
        sql_query_log = f"INSERT operations for SKU {row['SKU']}"

        # 1. Log to Blockchain File
        audit_chain.add_block(user_query_log, sql_query_log)

        # 2. Log to Database Table
        session.add(
            AuditLog(
                action="CSV Insert",
                user_query=user_query_log,
                sql_query=sql_query_log,
                hash_value=audit_chain.chain[-1].hash
            )
        )
        session.commit()

    except Exception as e:
        session.rollback()
        print(f"⚠️ Error processing row {index} (SKU: {row.get('SKU', 'Unknown')}): {e}")

session.close()

print("✅ CSV successfully converted and audited (Hybrid Blockchain + SQL Logs)")